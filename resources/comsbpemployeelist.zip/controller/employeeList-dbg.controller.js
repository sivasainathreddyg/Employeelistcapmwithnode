
    sap.ui.define([
        "sap/ui/core/mvc/Controller",
        "sap/m/MessageToast",
        "sap/m/MessageBox",
    ],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, toast, MessageBox) {
        "use strict";
        var that;
        return Controller.extend("com.sbp.employeelist.controller.employeeList", {
            onInit: function () {
                that = this;
                that.setKeyboardShortcuts(); //For setting up HotKeys to Create Button
            },
            onAfterRendering: function () {
                that.employeeData = []; //Used for storing table Data 
                var oModel = that.getOwnerComponent().getModel("eModel"); //getting Global Model of oData
                sap.ui.core.BusyIndicator.show();
                oModel.read("/Interactions_Header", {
                    success: function (data) {
                        data.results.forEach(m => m.newEmp = false);
                        that.employeeData = data.results;
                        that.bindToView(that.employeeData); //binding the Model to View
                        sap.ui.core.BusyIndicator.hide();
                    }
                })
                that.oi18n = this.getView().getModel("i18n").getResourceBundle(); //storing i18n as Global Variable
            },
            bindToView: function (aTableData) { //Binding Model to View
                var tModel = new sap.ui.model.json.JSONModel();
                tModel.setData({
                    empData: aTableData
                })
                that.getView().setModel(tModel);
            },
            //#region addEmployee Fragment
            modifyEmployee: function () {
                var iId = sap.ui.getCore().byId("txtEmpID").getValue();
                var sName = sap.ui.getCore().byId("txtEmpName").getValue();
                var sPhone = sap.ui.getCore().byId("txtPhone").getValue();
                if (sName.toString().trim() == '' || iId.toString().trim() == '') {
                    return toast.show(that.oi18n.getText("reqFields"));
                }
                if (sap.ui.getCore().byId("empTogglebtn").getText() == 'Save') { //redirecting to saveEmployee function if button is Save
                    return that.saveEmployee(parseInt(iId), sName, sPhone);
                }
                if (that.newEmpEdit) { //if selected record is newly created Employee just modifying the table items
                    let oEmpIndex = Array.from(that.employeeData).findIndex(f => f.empID == iId);
                    that.employeeData[oEmpIndex].empName = sName;
                    that.employeeData[oEmpIndex].phone = sPhone;
                    that.bindToView(that.employeeData);
                    toast.show(that.oi18n.getText("updated"))
                    that.closeDialog();
                } else {
                    var oModel = that.getOwnerComponent().getModel("eModel");
                    sap.ui.core.BusyIndicator.show();
                    oModel.callFunction("/updateEmployee", {
                        method: "GET",
                        urlParameters: {
                            eId: iId,
                            eName: sName,
                            ePhone: sPhone
                        },
                        success: function () {
                            toast.show(that.oi18n.getText("updated"))
                            that.closeDialog();
                            //To maintain the state of Table items, not calling Get request and just modifying table Items after update
                            let oEmpIndex = Array.from(that.employeeData).findIndex(f => f.empID == iId);
                            that.employeeData[oEmpIndex].empName = sName;
                            that.employeeData[oEmpIndex].phone = sPhone;
                            that.bindToView(that.employeeData);
                            sap.ui.core.BusyIndicator.hide();
                        },
                        error: function (error) {
                            sap.ui.core.BusyIndicator.hide();
                            toast.show(JSON.parse(error.responseText).error.message.value);
                        }
                    })
                }

            },
            resetClick: function () {
                sap.ui.getCore().byId("txtEmpID").setValue('').focus();
                sap.ui.getCore().byId("txtEmpName").setValue('');
                sap.ui.getCore().byId("txtPhone").setValue('');
            },
            saveEmployee: function (iId, sName, sPhone) {
                const oEmployee = {
                    empID: iId,
                    empName: sName,
                    phone: sPhone,
                    newEmp: true
                }
                that.employeeData.push(oEmployee); //New Employee Data created being pushed into Array
                that.bindToView(that.employeeData);
                that.resetClick();
                this.getView().byId("btnBatchSave").setEnabled(true); //enabling Save button for saving new Employee 
            },
            //Making PhoneNumber field to  accept only numbers as maxlength property is not applicable for number type
            numberChange: function (oEvent) {
                var _oInput = oEvent.getSource();
                var val = _oInput.getValue();
                val = val.replace(/[^\d]/g, '');
                _oInput.setValue(val);
            },
            closeDialog: function () {
                if (this.oIDialogFragment) {
                    this.oIDialogFragment.close();
                    this.oIDialogFragment.destroy(true)
                }
            },
            //#endregion

            //#region Events
            batchSave: function () {
                var aNewEmployees = Array.from(that.employeeData).filter(f => f.newEmp);
                if (aNewEmployees.length > 0) {
                    var oModel = that.getOwnerComponent().getModel("eModel");
                    Array.from(aNewEmployees).forEach(m => delete m.newEmp); //removing the flag which we setUp to identify new Employee
                    sap.ui.core.BusyIndicator.show();
                    oModel.callFunction("/saveEmployees", {
                        method: "GET",
                        urlParameters: {
                            employees: JSON.stringify(aNewEmployees)
                        },
                        success: function () {
                            sap.ui.core.BusyIndicator.hide();
                            toast.show(that.oi18n.getText("saved"))
                            that.onAfterRendering();
                            that.getView().byId("btnBatchSave").setEnabled(false);
                        },
                        error: function (error) {
                            sap.ui.core.BusyIndicator.hide();
                            toast.show(JSON.parse(error.responseText).error.message.value);
                        }
                    })
                }
            },
            deleteEmployees: function () {
                var aItems = this.getView().byId('empTable').getItems();
                var aSelectedItems = [];
                var alocalItems = [];
                //Filtering the new Added Employees and Existing Employees
                aItems.forEach(el => {
                    if (el.getSelected()) {
                        let oElement = el.getBindingContext().getObject();
                        if (oElement.newEmp) {
                            alocalItems.push(oElement.empID);
                        } else {
                            aSelectedItems.push(oElement.empID);
                        }
                        
                    }
                })
                if (aSelectedItems.length == 0 && alocalItems.length == 0) {
                    return toast.show(that.oi18n.getText("deleteValidation"))
                }
                MessageBox.warning(that.oi18n.getText("deleteConfirmation"), {
                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.OK,
                    onClose: function (sAction) {
                        if (sAction == 'OK') {
                            if (aSelectedItems.length > 0) { //If Existing Employees are selected
                                sap.ui.core.BusyIndicator.show();
                                var oModel = that.getOwnerComponent().getModel("eModel");
                                oModel.callFunction("/deleteEmployees", {
                                    method: "GET",
                                    urlParameters: {
                                        employeeIds: JSON.stringify(aSelectedItems)
                                    },
                                    success: function () {
                                        sap.ui.core.BusyIndicator.hide();
                                        toast.show(that.oi18n.getText("deleted"))
                                        sap.ui.core.BusyIndicator.hide();
                                        aSelectedItems.forEach(x => { //To preserve the state if new unsaved Employees manually removing them
                                            let iIndex = Array.from(that.employeeData).findIndex(f => f.empID == x);
                                            if (iIndex) {
                                                that.employeeData.splice(iIndex, 1);
                                            }
                                        })
                                        that.bindToView(that.employeeData);

                                    },
                                    error: function (error) {
                                        sap.ui.core.BusyIndicator.hide();
                                        toast.show(JSON.parse(error.responseText).error.message.value);
                                    },
                                })
                            }
                            if (alocalItems.length > 0) { //if Only newly added Employees are selected,Remove them from table
                                alocalItems.forEach(x => {
                                    let iIndex = Array.from(that.employeeData).findIndex(f => f.empID == x);
                                    if (iIndex) {
                                        that.employeeData.splice(iIndex, 1);
                                    }
                                })
                                that.bindToView(that.employeeData);
                                toast.show(that.oi18n.getText("deleted"))
                            }
                            if (Array.from(that.employeeData).findIndex(f => f.newEmp == true) == -1) { //disabling Save button if no new record Exists
                                that.getView().byId("btnBatchSave").setEnabled(false);
                            }
                        }
                    }
                });
            },
            removeEmployee: function (oEvent) { //removing only newly Added Employees
                var sEmpID = oEvent.getSource().oParent.oParent.getCells()[0].getProperty('text');
                let iIndex = Array.from(that.employeeData).findIndex(f => f.empID == sEmpID);
                that.employeeData.splice(iIndex, 1);
                that.bindToView(that.employeeData);
                if (Array.from(that.employeeData).findIndex(f => f.newEmp == true) == -1) {
                    this.getView().byId("btnBatchSave").setEnabled(false);
                }
            },
            search: function () {
                var aTableItems = this.getView().byId('empTable').getItems();
                var sEmpSearch = this.getView().byId("txtSearch").getValue();
                if (sEmpSearch.toString().trim() != '' && aTableItems.length > 0) {
                    var afilteredData = [];
                    //Filtering both search field equals to EmployeeId and starts with EmployeeName.
                    aTableItems.forEach(el => {
                        let oElement = el.getBindingContext().getObject();
                        if (oElement.empID == sEmpSearch || oElement.empName.toLowerCase().startsWith(sEmpSearch.toLowerCase())) {
                            afilteredData.push(el.getBindingContext().getObject());
                        }
                    })
                    that.bindToView(afilteredData);
                } else if (sEmpSearch.toString().trim() == "") {
                    that.bindToView(that.employeeData);
                }
                document.getElementById('form')
            },
            createEmployees: function () {//opening addEmployee Fragment
                if (!this.byId("openDialog")) {
                    this.oIDialogFragment = sap.ui.xmlfragment("com.sbp.employeelist.fragments.addEmployee", this.getView().getController());
                    this.getView().addDependent(this.oIDialogFragment);
                    this.oIDialogFragment.open();
                    //To prevent Fragment Close on Escape Key Press
                    this.oIDialogFragment.attachBrowserEvent("keydown", function (oEvent) {
                        if (oEvent.key == "Escape") {
                            oEvent.stopPropagation();
                            oEvent.preventDefault();
                        }
                    });
                } else {
                    this.byId("openDialog").open();
                }
            },
            editClick: function (oEvent) {
                that.newEmpEdit = false; //A flag to identify whether the new record is selected or not
                var sEmpID = oEvent.getSource().oParent.oParent.getCells()[0].getProperty('text');
                let oSelRec = Array.from(that.employeeData).find(f => f.empID == sEmpID);
                if (oSelRec) {
                    that.createEmployees();
                    sap.ui.getCore().byId("txtEmpID").setValue(oSelRec.empID).setEnabled(false);
                    sap.ui.getCore().byId("resetBtn").setEnabled(false);
                    sap.ui.getCore().byId("txtEmpName").setValue(oSelRec.empName).focus();
                    sap.ui.getCore().byId("txtPhone").setValue(oSelRec.phone);
                    sap.ui.getCore().byId("empTogglebtn").setText(that.oi18n.getText("update"));
                    sap.ui.getCore().byId("fragmentTitle").setText(that.oi18n.getText("fragmentEditTitle"));
                    if (oSelRec.newEmp) { //if edited Record is new Employee yet to be Saved,setting flag to true
                        that.newEmpEdit = true;
                    }
                }
            },
            setKeyboardShortcuts: function () {
                $(document).keydown($.proxy(function (e) {
                    switch (e.ctrlKey && e.altKey && e.keyCode) {
                        case 67:///Open Add Employee Dialog on Ctrl+Alt+c 
                            if (!$('#openDialog').html()) {
                                that.createEmployees();
                            }
                            break;
                    }
                }))
            },
            //#endregion
        });
    });
